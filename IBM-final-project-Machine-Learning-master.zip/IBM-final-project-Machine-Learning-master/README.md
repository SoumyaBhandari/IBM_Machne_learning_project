# IBM-final-project-Machine-Learning
Final project of IBM's course https://www.coursera.org/learn/machine-learning-with-python on coursera

A simple comparison between KNN,SVM,Decision Tree and Logistic Regression models on a given data set of loans records.
final results:


| Algorithm          | Jaccard | F1-score | LogLoss |
|--------------------|---------|----------|---------|
| KNN                | 0.7407  | 0.7144   | NA      |
| Decision Tree      | 0.7592  | 0.7618   | NA      |
| SVM                | 0.7592  | 0.6959   | NA      |
| LogisticRegression | 0.7777  | 0.7089   | 0.4947  |


Please read the note book for information about the data and implementation of classifiers used.

*Please note that results may be improved by engineering new features or using different hyper parameters ,I have tried just to create a simple prediction only for demonstrating use of different classifiers from scikit learn library .*
